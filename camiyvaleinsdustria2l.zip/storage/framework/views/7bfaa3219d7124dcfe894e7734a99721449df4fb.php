<!DOCTYPE html>
<html dir="ltr" lang="es">

<!-- Mirrored from html.kodesolution.live/h/dentalpro/v3.0/demo/features-header-modern-style5-white.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 01 Oct 2020 21:48:29 GMT -->
<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>

<?php echo $__env->yieldContent('metadata'); ?>

<!-- Page Title -->
<?php echo $__env->yieldContent('title'); ?>


<!-- Favicon and Touch Icons -->
<link href="<?php echo e(asset('img/favicon.png')); ?>" rel="shortcut icon" type="image/png">
<link href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
<link href="<?php echo e(asset('img/apple-touch-icon-72x72.png')); ?>" rel="apple-touch-icon" sizes="72x72">
<link href="<?php echo e(asset('img/apple-touch-icon-114x114.png')); ?>" rel="apple-touch-icon" sizes="114x114">
<link href="<?php echo e(asset('img/apple-touch-icon-144x144.png')); ?>" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/css-plugin-collections.css')); ?>" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link href="<?php echo e(asset('css/menuzord-megamenu.css')); ?>" rel="stylesheet"/>
<link id="menuzord-menu-skins" href="<?php echo e(asset('css/menuzord-skins/menuzord-boxed.css')); ?>" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="<?php echo e(asset('css/style-main.css')); ?>" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="<?php echo e(asset('css/preloader.css')); ?>" rel="stylesheet" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="<?php echo e(asset('css/custom-bootstrap-margin-padding.css')); ?>" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="<?php echo e(asset('js/revolution-slider/css/settings.css')); ?>" rel="stylesheet" type="text/css"/>
<link  href="<?php echo e(asset('js/revolution-slider/css/layers.css')); ?>" rel="stylesheet" type="text/css"/>
<link  href="<?php echo e(asset('js/revolution-slider/css/navigation.css')); ?>" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="<?php echo e(asset('css/colors/theme-skin-color-set5.css')); ?>" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script src="<?php echo e(asset('js/jquery-2.2.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="<?php echo e(asset('js/jquery-plugin-collection.js')); ?>"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script src="<?php echo e(asset('js/revolution-slider/js/jquery.themepunch.tools.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/revolution-slider/js/jquery.themepunch.revolution.min.js')); ?>"></script>
<?php echo $__env->yieldContent('links'); ?>


</head>


<body class="">
<div id="wrapper">
  <!-- preloader -->
  <div id="preloader">
    <div id="spinner">
      <div class="preloader-dot-loading">
        <img src="<?php echo e(asset('img/8.gif')); ?>" alt="preloader">      
      </div>
    </div>
    <div id="disable-preloader" class="btn btn-default btn-sm">desactivar preloader</div>
  </div>
  
  <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <!-- Start main-content -->
  <div class="main-content">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
  <!-- end main-content -->

  <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>




<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  
			(Load Extensions only on Local File Systems ! 
			 The following part can be removed on Server for On Demand Loading) -->
<script src="<?php echo e(asset('js/revolution-slider/js/extensions/revolution.extension.actions.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/revolution-slider/js/extensions/revolution.extension.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/revolution-slider/js/extensions/revolution.extension.kenburn.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/revolution-slider/js/extensions/revolution.extension.layeranimation.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/revolution-slider/js/extensions/revolution.extension.migration.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/revolution-slider/js/extensions/revolution.extension.navigation.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/revolution-slider/js/extensions/revolution.extension.parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/revolution-slider/js/extensions/revolution.extension.slideanims.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/revolution-slider/js/extensions/revolution.extension.video.min.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH C:\wamp64\www\camiyvaleinsdustrial\resources\views/layouts/template.blade.php ENDPATH**/ ?>