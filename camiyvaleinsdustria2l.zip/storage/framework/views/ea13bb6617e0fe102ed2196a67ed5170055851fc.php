

<?php $__env->startSection('metadata'); ?>
    <?php  
        $image= explode(',', $product->image) ;  
        $metaimage=asset($image[0]);  

        $title ="";
        if($category2->name == $product->name){
            $title = $product->name;
        }
        else{
            $title = $category2->name . ": " .$product->name;
        } 
    ?>
  <?php echo $__env->make('meta::manager', [
    'title'         => $title.  '  económico aquí en  CAMI & VALE INDUSTRIAL S.A.C',
    'description'   => $product->description,
    'keywords'   => $product->name. ', ' .$category2->name .', ' .$category2->description,
    'image' => $metaimage,
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('links'); ?>
    <style>
        .table-category{
            padding:1rem 1rem !important;
            border-left: 2px solid #447FEB;
            border-right: 2px solid #447FEB;
        }
        .table-category a{
            padding:1rem 2rem;
            text-transform :uppercase;
        }
    
    </style>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark"  data-bg-img="<?php echo e(asset('img/bg/product.jpg')); ?>" loading="lazy">
        <div class="container pt-100 pb-50">
          <!-- Section Content -->
          <div class="section-content pt-50">
            <div class="row"> 
              <div class="col-sm-8 text-left flip xs-text-center">
                <h2 class="title text-white"><?php echo e($product->name); ?>  </h2>
              </div>
              <div class="col-sm-4">
                <ol class="breadcrumb text-right sm-text-center text-black mt-10">
                  <li><a href="<?php echo e(route('home.index')); ?>" class="text-white">Inicio</a></li>
                  <li><a href="<?php echo e(route('product.index')); ?>" class="text-white"><?php echo e($category2->name); ?></a></li>
                  <li class="active text-theme-colored"><?php echo e($product->name); ?></li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </section>

    <section style=>
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8 hidden-xs hidden-sm">
                <div class="table-responsive" >
                    <table class="table" style="background: #fff; position: absolute;top:-1.5rem; ">
                        <thead>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="table-category"><a href="<?php echo e(route('product.show', $category)); ?>"><?php echo e($category->name); ?></a></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </thead>
                    </table>
                </div>
            </div>
        </div>


        <div class="container mt-30 mb-30 pt-30 pb-30">
        <div class="row">
            <div class="col-md-10 pull-right flip sm-pull-none">
            <div class="blog-posts">
                <div class="col-md-12">
                <div class="row list-dashed">
                    <article class="post clearfix mb-30 pb-30">
                        <div class="entry-header">
                            <div class="post-thumb thumb"> 
                            </div>
                        </div>
                        <div class="entry-content border-1px p-20 pr-10">
                            <div class="row">
                                <h2 class="alert alert-danger text-uppercase ">
                                    <?php if($category2->name == $product->name): ?>
                                        <?php echo e($product->name); ?>

                                    <?php else: ?> 
                                        <?php echo e($category2->name); ?> :: <?php echo e($product->name); ?>

                                    <?php endif; ?>
                                </h2>
                                <div class="col-md-8">
                                   <?php echo $product->description; ?>

                                </div>
                                <div class="col-md-4">
                                    <hr>
                                    <div id="carousel1" class="carousel slide mt-60" data-ride="carousel">
                                        <ol class="carousel-indicators">
                                            <li data-target="#carousel1" data-slide-to="0" class="active"></li>
                                            <li data-target="#carousel1" data-slide-to="1"></li>
                                            <li data-target="#carousel1" data-slide-to="2"></li>
                                            <li data-target="#carousel1" data-slide-to="3"></li>
                                        </ol>
                                        <div class="carousel-inner" role="listbox">
                                            <div class="item active">
                                                <img src="<?php echo e(asset($image[0])); ?>" class="d-block w-100" alt="<?php echo e($product->name); ?>-1" loading="lazy">
                                            </div>
                        
                                            <div class="item">
                                                <img src="<?php echo e(asset($image[1])); ?>" class="d-block w-100" alt="<?php echo e($product->name); ?>-2" loading="lazy">
                                            </div>
                        
                                            <div class="item">
                                                <img src="<?php echo e(asset($image[2])); ?>" class="d-block w-100" alt="<?php echo e($product->name); ?>-3" loading="lazy">
                                            </div>
                                            <div class="item">
                                                <img src="<?php echo e(asset($image[3])); ?>" class="d-block w-100" alt="<?php echo e($product->name); ?>-4" loading="lazy">
                                            </div>
                                        </div>
                                        <a class="left carousel-control" href="#carousel1" role="button" data-slide="prev">
                                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                                            <span class="sr-only">Anterior</span>
                                        </a>
                                        <a class="right carousel-control" href="#carousel1" role="button" data-slide="next">
                                            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                                            <span class="sr-only">Siguiente</span>
                                        </a>
                                        </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>

                    </article>

                </div>
                </div>
                
            </div>
            </div>
            <div class="col-md-2">
            <div class="sidebar sidebar-right mt-sm-30">
                <div class="widget">
                <h5 class="widget-title"><?php echo e($category2->name); ?> </h5>
                <ul class="list-divider list-border list check">
                    <?php $__currentLoopData = $category2->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $category =$category2 ?>
                        <li><a href="<?php echo e(route('product.product',[$category,$product])); ?>"><?php echo e($product->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                </div>
            </div>
            </div>
        </div>
        </div>
    </section> 
    <!-- end main-content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\camiyvaleinsdustrial\resources\views/product/show.blade.php ENDPATH**/ ?>