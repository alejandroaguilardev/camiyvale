<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contacto</title>
</head>
<body>
    <h1>CAMI & VALE INDUSTRIAL S.A.C</h1>
    <p><strong>Asunto:</strong> <?php echo e($param['asunto']); ?></p><br>
    <p><strong>Nombre:</strong><?php echo e($param['nombre']); ?></p>
    <p><strong>Email:</strong><?php echo e($param['correo']); ?></p>
    <p><strong>telefono:</strong><?php echo e($param['telefono']); ?></p>
    <hr>
    <p><strong>Descripción:</strong><?php echo e($param['mensaje']); ?></p>
    
</body>
</html><?php /**PATH C:\wamp64\www\camiyvaleinsdustrial\resources\views/contact/mail.blade.php ENDPATH**/ ?>