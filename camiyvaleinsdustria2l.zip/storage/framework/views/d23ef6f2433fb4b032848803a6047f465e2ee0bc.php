

<?php $__env->startSection('metadata'); ?>
  <?php echo $__env->make('meta::manager', [
    'title'         => 'CAMI & VALE INDUSTRIAL S.A.C - Contáctanos',
    'description'   => 'Somos una empresa peruana puede encontrarnos en el distrito de San miguel en Lima   comercializadores de productos y ofrecemos diversos servicios',
    'keywords'   => ' Calle San Carlos 163 Urb. Santa Florencia - San Miguel Lima-Perú, 691 4753 / 944 731 380, ventas@camiyvaleindustrial.com,  San Miguel, Lima, cotiza'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark"  data-bg-img="<?php echo e(asset('img/bg/contacto.jpg')); ?>">
        <div class="container pt-100 pb-50">
          <!-- Section Content -->
          <div class="section-content pt-50">
            <div class="row"> 
              <div class="col-sm-8 text-left flip xs-text-center">
                <h2 class="title text-white">Contáctanos</h2>
              </div>
              <div class="col-sm-4">
                <ol class="breadcrumb text-right sm-text-center text-black mt-10">
                  <li><a href="<?php echo e(route('home.index')); ?>" class="text-white">Inicio</a></li>
                  <li class="active text-theme-colored">Contáctanos</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </section>

      
      
      <!-- Divider: Contact -->
      <section class="divider">
        <div class="container">
          <div class="row pt-30">
            <div class="col-md-4">
              <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="icon-box left media bg-deep p-30 mb-20"> <a class="media-left pull-left" href="#"> <i class="pe-7s-map-2 text-theme-colored"></i></a>
                    <div class="media-body">
                      <h5 class="mt-0">Dirección de Contacto</h5>
                      <p><?php echo e($informations->direction); ?></p>
                    </div>
                  </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-12">
                  <div class="icon-box left media bg-deep p-30 mb-20"> <a class="media-left pull-left" href="#"> <i class="pe-7s-call text-theme-colored"></i></a>
                    <div class="media-body">
                      <h5 class="mt-0">Números de Contacto</h5>
                      <p><?php echo e($informations->phone); ?> / <?php echo e($informations->mobile); ?></p>
                    </div>
                  </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-12">
                  <div class="icon-box left media bg-deep p-30 mb-20"> <a class="media-left pull-left" href="#"> <i class="pe-7s-mail text-theme-colored"></i></a>
                    <div class="media-body">
                      <h5 class="mt-0">Correo Electrónico</h5>
                      <p><?php echo e($informations->email); ?></p>
                    </div>
                  </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-12">
                  <div class="icon-box left media bg-deep p-30 mb-20"> <a class="media-left pull-left" href="#"> <i class="fa fa-skype text-theme-colored"></i></a>
                    <div class="media-body">
                      <h5 class="mt-0">Horario de Atención</h5>
                      <p><?php echo e($informations->schedule); ?></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-8">
              <h3 class="line-bottom mt-0 mb-30">¿Interesado en Cotizar?</h3>
              <?php if(session('alert')): ?>
                  <div class="alert alert-success"><?php echo e(session('alert')); ?></div>
              <?php endif; ?>
              <!-- Contact Form -->
              <form action="<?php echo e(route('contact.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                      <label>Nombre <small>*</small></label>
                      <input name="nombre" class="form-control" type="text" value="<?php echo e(old('name')); ?>" placeholder="Ingresar Nombre" required style="text-transform:capitalize;">
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="form-group">
                      <label>Email <small>*</small></label>
                      <input name="correo" class="form-control required email"  value="<?php echo e(old('email')); ?>" type="email" placeholder="Ingresar Correo" required >
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                </div>
                  
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label>Asunto <small>*</small></label>
                      <input name="asunto" class="form-control required" type="text" value="<?php echo e(old('subject')); ?>" placeholder="Ingresar Asunto" required>
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label>Teléfono</label>
                      <input name="telefono" class="form-control" type="text"  value="<?php echo e(old('message')); ?>" placeholder="Ingresar Teléfono" required>
                      <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                </div>
  
                <div class="form-group">
                  <label>Mensaje</label>
                  <textarea name="mensaje" class="form-control required" rows="5" placeholder="Ingresar Mensaje" required></textarea>
                  <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-dark btn-theme-colored btn-flat mr-5" >Enviar Tu Mensaje</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
    <!-- end main-content -->
  

          
      <!-- Divider: Google Map -->
      <section>
        <div class="container-fluid pt-0 pb-0">
          <div class="row">
  
            <!-- Google Map HTML Codes -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.417359487283!2d-77.07818128532385!3d-12.083554791442793!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9105c90ba294ea99%3A0xb41ea2ec21e535bb!2sCalle%20San%20Carlos%20163%2C%20San%20Miguel%2015086!5e0!3m2!1ses!2spe!4v1611960915361!5m2!1ses!2spe" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>  
          </div>
        </div>
      </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\camiyvaleinsdustrial\resources\views/contact/index.blade.php ENDPATH**/ ?>